
// utils/ping.js - simple TCP ping using fetch to common ports
export const Ping = {
  async ping(ip, timeout=500){
    // Try to connect via fetch to port 80, or use native module kung available
    try {
      const start = Date.now();
      // Sa Expo, gagamit tayo ng simple socket check - for demo gumamit ng random alive
      // Sa totoong build, palitan ng react-native-tcp-socket
      const controller = new AbortController();
      const id = setTimeout(() => controller.abort(), timeout);
      
      // Try common check - kung may response sa http
      // Mas accurate kung native module, pero ito working baseline
      await fetch(`http://${ip}:80`, { signal: controller.signal, mode: 'no-cors' }).catch(()=>{});
      clearTimeout(id);
      const time = Date.now() - start;
      
      // Kung mabilis bumalik (< timeout), consider alive
      // Sa real app, dapat ICMP ping via native code
      if(time < timeout){
        return { time, hostname: `Unknown-${ip.split('.').pop()}`, mac: null };
      }
      return null;
    } catch(e){
      return null;
    }
  }
}
