
// utils/realPing.js - 100% REAL, walang simulation
import TcpSocket from 'react-native-tcp-socket';

export function realTcpPing(ip, port=80, timeout=500){
  return new Promise(resolve => {
    const start = Date.now();
    const socket = TcpSocket.createConnection({ host: ip, port, timeout }, () => {
      const latency = Date.now() - start;
      socket.destroy();
      resolve({ alive: true, latency, ip });
    });
    socket.on('error', () => {
      socket.destroy();
      resolve({ alive: false, ip });
    });
    socket.on('timeout', () => {
      socket.destroy();
      resolve({ alive: false, ip });
    });
  });
}

// Scan buong subnet ng REAL
export async function scanSubnet(baseIp, onFound){
  const aliveHosts = [];
  for(let i=1; i<=254; i++){
    const ip = baseIp + i;
    // Try port 80, 443, 53 - common open ports
    const r1 = await realTcpPing(ip, 80, 350);
    if(r1.alive){ aliveHosts.push(r1); onFound && onFound(r1); continue; }
    const r2 = await realTcpPing(ip, 443, 350);
    if(r2.alive){ aliveHosts.push(r2); onFound && onFound(r2); }
  }
  return aliveHosts;
}
