
// utils/realPing.js - 100% REAL, no simulation
import TcpSocket from 'react-native-tcp-socket';

export function realTcpPing(ip, port=80, timeout=500){
  return new Promise(resolve => {
    const start = Date.now();
    const socket = TcpSocket.createConnection({ host: ip, port, timeout }, () => {
      const latency = Date.now() - start;
      socket.destroy();
      resolve({ alive: true, latency, ip });
    });
    socket.on('error', () => {
      socket.destroy();
      resolve({ alive: false, ip });
    });
    socket.on('timeout', () => {
      socket.destroy();
      resolve({ alive: false, ip });
    });
  });
}
